PRIMEAI — FREE STARTER WEBSITE
===============================

WHAT'S INCLUDED
- Responsive PrimeAI chat website
- Chat history saved in this browser
- Installable PWA shell and offline loading of the interface
- Secure server-side Gemini API connection (the secret key is NOT placed in browser code)
- Cloudflare Pages Function at functions/api/chat.js

IMPORTANT
The website files are free to use. To get real AI answers, you need a Google Gemini API key.
Google currently offers a free tier for some Gemini models, with limits that can change.
Review the current pricing, quotas, and data terms before using it:
https://ai.google.dev/gemini-api/docs/pricing

The free tier may use submitted content to improve Google's products. Do not send passwords,
private records, or sensitive personal information. Free quotas can run out or change.

DEPLOY WITHOUT WRITING CODE (Cloudflare Pages + GitHub)
1. Extract this ZIP on your phone or computer.
2. Create/sign in to GitHub: https://github.com/
3. Create a new repository named primeai. Upload all extracted FILES and FOLDERS
   (upload the contents, not the ZIP itself). Keep the functions folder.
4. Create a free Cloudflare account: https://dash.cloudflare.com/
5. In Cloudflare, open Workers & Pages > Create > Pages > Connect to Git.
6. Select your primeai GitHub repository.
7. For a plain HTML project, set:
   Framework preset: None
   Build command: leave blank
   Build output directory: /
   Then deploy.
8. Open Google AI Studio: https://aistudio.google.com/app/apikey
   Create an API key. Do not share it with anyone.
9. In your Cloudflare Pages project, open Settings > Variables and Secrets
   (or Functions > Environment variables, depending on the dashboard version).
   Add a secret named GEMINI_API_KEY and paste your key as its value.
10. Optionally add a variable named GEMINI_MODEL with value gemini-2.5-flash.
11. Redeploy the project so the Function receives the secret.
12. Open your Cloudflare Pages URL and test a chat.

IF THE CHAT DOES NOT WORK
- Confirm GEMINI_API_KEY is saved as a secret and redeploy.
- Check the current model name and free-tier availability in Google's docs.
- Check your Google AI Studio quota. A free quota limit can temporarily stop replies.
- Never paste your API key into index.html or app.js.

OFFLINE NOTE
The app shell and locally saved chat history can open offline after the first successful visit.
AI responses require an internet connection and a working API quota.

CURRENT LIMITATIONS
- This is a starter app, not a full multi-user product.
- Chat history is stored only in the current browser/device.
- There is no user login, cloud sync, admin panel, or abuse-protection/rate-limit system yet.
- Before sharing publicly, add proper rate limiting and user authentication so strangers
  cannot exhaust your free API quota.
