export async function onRequestPost(context) {
  const { request, env } = context;
  if (!env.GEMINI_API_KEY) {
    return json({ error: "AI setup is not finished yet. Add your Gemini API key as GEMINI_API_KEY in your hosting dashboard." }, 503);
  }
  let body;
  try { body = await request.json(); } catch { return json({ error: "Invalid request." }, 400); }
  if (!Array.isArray(body.messages) || body.messages.length === 0 || body.messages.length > 16) {
    return json({ error: "Please send a valid chat with up to 16 recent messages." }, 400);
  }
  const contents = [];
  for (const m of body.messages) {
    const text = typeof m?.parts?.[0]?.text === "string" ? m.parts[0].text.slice(0, 4000) : "";
    if (!text || !["user", "model"].includes(m.role)) continue;
    contents.push({ role: m.role, parts: [{ text }] });
  }
  if (!contents.length || contents[contents.length - 1].role !== "user") return json({ error: "Please send a message." }, 400);

  const model = env.GEMINI_MODEL || "gemini-2.5-flash";
  const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;
  try {
    const upstream = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": env.GEMINI_API_KEY },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: "You are PrimeAI, a helpful, clear, friendly AI assistant. Be honest about uncertainty and explain things in simple language when useful." }] },
        contents,
        generationConfig: { temperature: 0.7, maxOutputTokens: 1200 }
      })
    });
    const data = await upstream.json();
    if (!upstream.ok) {
      const message = data?.error?.message || "The AI provider returned an error.";
      return json({ error: message }, upstream.status === 429 ? 429 : 502);
    }
    const text = data?.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("").trim();
    if (!text) return json({ error: "The AI did not return text. Please try again." }, 502);
    return json({ text });
  } catch {
    return json({ error: "Could not connect to the AI provider. Please try again." }, 502);
  }
}
function json(data, status=200) {
  return new Response(JSON.stringify(data), { status, headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" } });
}
