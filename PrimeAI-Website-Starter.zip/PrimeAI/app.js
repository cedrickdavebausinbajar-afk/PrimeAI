const $ = (s) => document.querySelector(s);
const messagesEl = $("#messages"), welcomeEl = $("#welcome"), promptEl = $("#prompt");
let chats = JSON.parse(localStorage.getItem("primeai_chats") || "[]");
let activeId = null, busy = false;

function save(){ localStorage.setItem("primeai_chats", JSON.stringify(chats)); renderHistory(); }
function currentChat(){
  let chat = chats.find(c => c.id === activeId);
  if(!chat){ chat={id:crypto.randomUUID(),title:"New chat",messages:[],updated:Date.now()}; chats.unshift(chat); activeId=chat.id; }
  return chat;
}
function renderHistory(){
  const box=$("#history"); box.innerHTML="";
  chats.slice().sort((a,b)=>b.updated-a.updated).forEach(chat=>{
    const b=document.createElement("button"); b.className="history-item"+(chat.id===activeId?" active":""); b.textContent=chat.title;
    b.onclick=()=>openChat(chat.id); box.appendChild(b);
  });
}
function safeText(text){ return text.replace(/[&<>]/g, c=>({"&":"&amp;","<":"&lt;",">":"&gt;"}[c])); }
function addMessage(role,text){
  const wrap=document.createElement("div"); wrap.className="message "+role;
  const avatar=document.createElement("div"); avatar.className="avatar"; avatar.textContent=role==="user"?"Y":"P";
  const bubble=document.createElement("div"); bubble.className="bubble";
  // Keep model output as plain text; do not interpret HTML or scripts.
  bubble.innerHTML=safeText(text).split(/\n{2,}/).map(p=>`<p>${p.replace(/\n/g,"<br>")}</p>`).join("");
  wrap.append(avatar,bubble); messagesEl.appendChild(wrap); return bubble;
}
function paint(){
  messagesEl.innerHTML=""; const chat=chats.find(c=>c.id===activeId);
  const has=chat && chat.messages.length; welcomeEl.hidden=!!has;
  if(has) chat.messages.forEach(m=>addMessage(m.role,m.text));
  renderHistory(); scrollBottom();
}
function scrollBottom(){ requestAnimationFrame(()=>{const c=$("#conversation");c.scrollTop=c.scrollHeight;}); }
function openChat(id){activeId=id;paint();$("#sidebar").classList.remove("open");}
function newChat(){activeId=null;messagesEl.innerHTML="";welcomeEl.hidden=false;renderHistory();promptEl.focus();$("#sidebar").classList.remove("open");}
function toast(msg){const t=$("#toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2600);}
async function send(text){
  text=text.trim(); if(!text||busy)return;
  const chat=currentChat(); chat.messages.push({role:"user",text}); chat.updated=Date.now();
  if(chat.title==="New chat") chat.title=text.slice(0,32)+(text.length>32?"…":"");
  welcomeEl.hidden=true; addMessage("user",text); save();
  promptEl.value=""; promptEl.style.height="auto"; busy=true; $("#sendButton").disabled=true;
  const loading=addMessage("assistant",""); loading.innerHTML='<span class="typing">PrimeAI is thinking…</span>'; scrollBottom();
  try{
    const response=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({messages:chat.messages.slice(-16).map(m=>({role:m.role==="assistant"?"model":"user",parts:[{text:m.text}]}))})});
    const data=await response.json();
    if(!response.ok) throw new Error(data.error||"The AI service is not available right now.");
    const answer=data.text||"I couldn't generate a response. Please try again.";
    loading.textContent=answer; chat.messages.push({role:"assistant",text:answer}); chat.updated=Date.now(); save();
  }catch(err){
    const msg=err.message.includes("Failed to fetch")?"PrimeAI cannot reach its AI service. Check your internet connection and setup.":err.message;
    loading.textContent=msg; loading.classList.add("typing");
  }finally{busy=false;$("#sendButton").disabled=false;scrollBottom();}
}
$("#chatForm").addEventListener("submit",e=>{e.preventDefault();send(promptEl.value);});
promptEl.addEventListener("input",()=>{promptEl.style.height="auto";promptEl.style.height=Math.min(promptEl.scrollHeight,150)+"px";});
promptEl.addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();$("#chatForm").requestSubmit();}});
$("#newChat").onclick=newChat;
$("#menuButton").onclick=()=>$("#sidebar").classList.toggle("open");
$("#clearHistory").onclick=()=>{if(confirm("Delete all saved chat history on this device?")){chats=[];activeId=null;save();paint();}};
document.querySelectorAll(".suggestion").forEach(b=>b.addEventListener("click",()=>send(b.dataset.prompt)));
if(chats.length) openChat(chats[0].id); else paint();
if("serviceWorker" in navigator) window.addEventListener("load",()=>navigator.serviceWorker.register("/sw.js").catch(()=>{}));
